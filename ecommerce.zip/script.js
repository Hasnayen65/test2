// Combined JS for Home, Cart, Admin, Invoice
// (Use the full script.js content provided earlier)